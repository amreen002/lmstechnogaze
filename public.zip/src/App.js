import './App.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Logins from './Routers/loginRouter';
import Dashboards from './Routers/dashboardsRouter';
import AddUserRouters from './Routers/addUserRouter';
import AccountUserRouters from './Routers/accountUserRouters.js';
import UserListRouters from './Routers/listUserRouters.js';
import UserViewsRouters from './Routers/viewsUserRouters.js';
import AddSaleTeamRouters from './Routers/addsaleteamRouters.js';
import TeleCallerRouters from './Routers/telecallerRouters.js';
import TeleCallerTeamRouters from './Routers/telecallerteamRouters.js'
import RoleRouters from './Routers/roleRouters.js'
function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  const handleLogin = async (email, password) => {
    try {
      const response = await axios.post('http://localhost:3000/api/login', { email, password });
      localStorage.setItem('token', response.data.token);
      alert(JSON.stringify(response.data.message));
      //const data = await response.json(); 
      //const { roleName, name } = data; 
      //localStorage.setItem('user', JSON.stringify({ roleName, name })) 
      setLoggedIn(true);
    } catch (error) {
      alert(error.message);
      console.error(error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setLoggedIn(false);
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/login"
          element={!loggedIn ? <Logins onLogin={handleLogin} /> : <Navigate to="/dashboard" />}
        />
        <Route
          path="/dashboard"
          element={loggedIn ? <Dashboards onLogout={handleLogout} /> : <Navigate to="/login" />}
        />
        <Route
          path="/adduser"
          element={<AddUserRouters onLogout={handleLogout} />}
        />
        <Route
          path="/accountusers"
          element={<AccountUserRouters />}
        />
        <Route
          path="/userlist"
          element={<UserListRouters onLogout={handleLogout} />}
        />
        <Route
          path="/userviews/:usersId"
          element={<UserViewsRouters onLogout={handleLogout} />}
        />
        <Route
          path="/addsaleteam"
          element={<AddSaleTeamRouters onLogout={handleLogout} />}
        />
        <Route
          path="/addsaleteam/:saleteamId"
          element={<AddSaleTeamRouters />}
        />
        <Route
          path="/telecaller"
          element={<TeleCallerRouters />}
        />
        <Route
          path="/telecallerteam"
          element={<TeleCallerTeamRouters />}
        />
        <Route
          path="/role"
          element={<RoleRouters />}
        />
        <Route
          path="/role/:roleId"
          element={<RoleRouters />}
        />
      </Routes>


    </BrowserRouter>
  );
}

export default App;
